package com.ggames.launcher

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class OptionsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_options)

        val etName = findViewById<EditText>(R.id.etName)
        val etIp = findViewById<EditText>(R.id.etIp)
        val etPort = findViewById<EditText>(R.id.etPort)
        val swDirect = findViewById<SwitchCompat>(R.id.swDirect)

        etName.setText(Prefs.name(this))
        etIp.setText(Prefs.ip(this))
        etPort.setText(Prefs.port(this).toString())
        swDirect.isChecked = Prefs.direct(this)

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            val port = etPort.text.toString().toIntOrNull()?.takeIf { it in 1..65535 } ?: 19132
            Prefs.save(
                this,
                etName.text.toString().trim().ifBlank { "GG Games" },
                etIp.text.toString().trim(),
                port,
                swDirect.isChecked
            )
            Toast.makeText(this, R.string.saved, Toast.LENGTH_SHORT).show()
            finish()
        }
        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
    }
}
