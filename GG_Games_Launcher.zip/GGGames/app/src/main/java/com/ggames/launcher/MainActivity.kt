package com.ggames.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPlay).setOnClickListener { play() }
        findViewById<Button>(R.id.btnOptions).setOnClickListener {
            startActivity(Intent(this, OptionsActivity::class.java))
        }
        findViewById<Button>(R.id.btnExit).setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            finishAffinity()
        }
    }

    private fun play() {
        if (Prefs.ip(this).trim().isEmpty()) {
            Toast.makeText(this, R.string.need_ip, Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, OptionsActivity::class.java))
            return
        }
        if (Prefs.overlay(this)) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                return
            }
            ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        }
        McLauncher.open(this)
    }
}
