package com.ggames.launcher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val mcPackage = "com.mojang.minecraftpe"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPlay).setOnClickListener { play() }
        findViewById<Button>(R.id.btnOptions).setOnClickListener {
            startActivity(Intent(this, OptionsActivity::class.java))
        }
        findViewById<Button>(R.id.btnExit).setOnClickListener { finishAffinity() }
    }

    private fun play() {
        val ip = Prefs.ip(this).trim()
        if (ip.isEmpty()) {
            Toast.makeText(this, R.string.need_ip, Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, OptionsActivity::class.java))
            return
        }
        val port = Prefs.port(this)
        val name = Prefs.name(this).ifBlank { "GG Games" }

        val uri = if (Prefs.direct(this)) {
            "minecraft://connect/?serverUrl=$ip&serverPort=$port"
        } else {
            "minecraft://?addExternalServer=${Uri.encode(name)}|$ip:$port"
        }
        launchMinecraft(uri)
    }

    private fun launchMinecraft(uri: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
            setPackage(mcPackage)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val launch = packageManager.getLaunchIntentForPackage(mcPackage)
            if (launch != null) {
                startActivity(launch)
            } else {
                Toast.makeText(this, R.string.no_mc, Toast.LENGTH_LONG).show()
                try {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$mcPackage"))
                    )
                } catch (_: ActivityNotFoundException) {
                }
            }
        }
    }
}
