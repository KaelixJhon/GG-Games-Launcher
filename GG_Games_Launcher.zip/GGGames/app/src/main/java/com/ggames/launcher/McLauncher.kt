package com.ggames.launcher

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

object McLauncher {
    const val PKG = "com.mojang.minecraftpe"

    fun open(c: Context) {
        val ip = Prefs.ip(c).trim()
        val port = Prefs.port(c)
        val name = Prefs.name(c).ifBlank { "GG Games" }

        val uri = if (Prefs.direct(c)) {
            "minecraft://connect/?serverUrl=$ip&serverPort=$port"
        } else {
            "minecraft://?addExternalServer=${Uri.encode(name)}|$ip:$port"
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
            setPackage(PKG)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            c.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val launch = c.packageManager.getLaunchIntentForPackage(PKG)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(launch)
            } else {
                Toast.makeText(c, R.string.no_mc, Toast.LENGTH_LONG).show()
                try {
                    c.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$PKG"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: ActivityNotFoundException) {
                }
            }
        }
    }
}
