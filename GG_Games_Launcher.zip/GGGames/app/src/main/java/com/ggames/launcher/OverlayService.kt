package com.ggames.launcher

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min

/**
 * DEMO: menú flotante "GG" dibujado ENCIMA de Minecraft.
 * No toca el código del juego (no inyecta nada): solo es una ventana encima.
 */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var cross: View? = null
    private var clock: TextView? = null
    private var panelShown = false
    private val handler = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            clock?.text = fmt.format(Date())
            handler.postDelayed(this, 1000)
        }
    }

    private val gold = Color.parseColor("#F5C542")
    private val brown = Color.parseColor("#3A1A0A")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundNow()
        if (bubble == null) createViews()
        return START_NOT_STICKY
    }

    private fun startForegroundNow() {
        val ch = "gg_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(ch, "Menú GG", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n = NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.star_on)
            .setContentTitle("GG Games")
            .setContentText("Menú GG activo dentro del juego")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun params(w: Int, h: Int, touchable: Boolean, gravity: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        if (!touchable) flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        ).apply { this.gravity = gravity }
    }

    private fun roundBg(fill: Int, stroke: Int, radiusDp: Int, oval: Boolean = false) =
        GradientDrawable().apply {
            if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            setStroke(dp(2), stroke)
        }

    @SuppressLint("ClickableViewAccessibility")
    private fun createViews() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        // Mira dorada (no tocable)
        val c = CrossView(this, gold)
        cross = c
        wm.addView(c, params(dp(26), dp(26), false, Gravity.CENTER))

        // Reloj (no tocable)
        val t = TextView(this).apply {
            setTextColor(gold)
            textSize = 15f
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            text = fmt.format(Date())
        }
        clock = t
        wm.addView(t, params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { y = dp(6) })
        handler.postDelayed(tick, 1000)

        // Botón flotante GG (arrastrable)
        val b = TextView(this).apply {
            text = "GG"
            gravity = Gravity.CENTER
            setTextColor(brown)
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            background = roundBg(gold, brown, 0, oval = true)
        }
        bubble = b
        val bp = params(dp(46), dp(46), true, Gravity.TOP or Gravity.START).apply {
            x = dp(12); y = dp(120)
        }
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = bp.x; sy = bp.y; tx = e.rawX; ty = e.rawY; moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (e.rawX - tx).toInt()
                        val dy = (e.rawY - ty).toInt()
                        if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                        if (moved) {
                            bp.x = sx + dx; bp.y = sy + dy
                            wm.updateViewLayout(v, bp)
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) togglePanel()
                }
                return true
            }
        })
        wm.addView(b, bp)

        panel = buildPanel()
    }

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun buildPanel(): LinearLayout {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = roundBg(Color.parseColor("#F00C0612"), gold, 12)
        }
        p.addView(TextView(this).apply {
            text = "GG Games"
            setTextColor(gold)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        })

        fun sw(label: String, on: Boolean, action: (Boolean) -> Unit) = Switch(this).apply {
            text = label
            isChecked = on
            setTextColor(Color.WHITE)
            setOnCheckedChangeListener { _, v -> action(v) }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        p.addView(sw("Mira dorada", true) { cross?.visibility = if (it) View.VISIBLE else View.GONE })
        p.addView(sw("Reloj", true) { clock?.visibility = if (it) View.VISIBLE else View.GONE })

        fun btn(label: String, goldBtn: Boolean, action: () -> Unit) = Button(this).apply {
            text = label
            setTextColor(if (goldBtn) brown else gold)
            background = roundBg(if (goldBtn) gold else Color.parseColor("#2A1608"), if (goldBtn) brown else gold, 8)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(44)
            ).apply { topMargin = dp(12) }
        }
        p.addView(btn("Entrar al servidor", true) { togglePanel(); McLauncher.open(this) })
        p.addView(btn("Cerrar menú GG", false) { stopSelf() })
        return p
    }

    private fun togglePanel() {
        val p = panel ?: return
        if (panelShown) {
            wm.removeView(p)
        } else {
            wm.addView(p, params(dp(270), WindowManager.LayoutParams.WRAP_CONTENT, true, Gravity.CENTER))
        }
        panelShown = !panelShown
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try {
            if (panelShown) panel?.let { wm.removeView(it) }
            bubble?.let { wm.removeView(it) }
            cross?.let { wm.removeView(it) }
            clock?.let { wm.removeView(it) }
        } catch (_: Exception) {
        }
        bubble = null; panel = null; cross = null; clock = null; panelShown = false
        super.onDestroy()
    }

    private class CrossView(c: Context, color: Int) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            strokeWidth = 3f * resources.displayMetrics.density
        }

        override fun onDraw(canvas: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val r = min(width, height) / 2f
            canvas.drawLine(cx - r, cy, cx + r, cy, p)
            canvas.drawLine(cx, cy - r, cx, cy + r, p)
        }
    }
}
