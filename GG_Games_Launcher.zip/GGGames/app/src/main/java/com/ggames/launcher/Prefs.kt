package com.ggames.launcher

import android.content.Context

object Prefs {
    private const val FILE = "gg_prefs"
    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun name(c: Context): String = sp(c).getString("name", "GG Games") ?: "GG Games"
    fun ip(c: Context): String = sp(c).getString("ip", "") ?: ""
    fun port(c: Context): Int = sp(c).getInt("port", 19132)
    fun direct(c: Context): Boolean = sp(c).getBoolean("direct", true)
    fun overlay(c: Context): Boolean = sp(c).getBoolean("overlay", true)

    fun save(c: Context, name: String, ip: String, port: Int, direct: Boolean, overlay: Boolean) {
        sp(c).edit()
            .putString("name", name)
            .putString("ip", ip)
            .putInt("port", port)
            .putBoolean("direct", direct)
            .putBoolean("overlay", overlay)
            .apply()
    }
}
