GG Games Launcher
=================
1. Android Studio > File > Open > carpeta GGGames. Espera a que sincronice Gradle.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. APK en app/build/outputs/apk/debug/app-debug.apk

Cambiar cosas:
- Fondo:  app/src/main/res/drawable-nodpi/bg_main.jpg
- Logo:   app/src/main/res/drawable-nodpi/logo_gg.png
- Nombre: app/src/main/res/values/strings.xml (app_name)
- IP/puerto: dentro de la app, en OPCIONES.
